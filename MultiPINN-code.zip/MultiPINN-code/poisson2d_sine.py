# Solve Poisson equation in 2D using SPINN
# \nabla^2 u(x, y) = 20pi^2 sin(2pi x) sin(4pi y) on [0,1]x[0,1]
# Zero Dirichlet boundary condition on boundary

import numpy as np
import torch
from pde2d_base import RegularPDE
from common import tensor
#from spinn2d import Plotter2D, SPINN2D, App2D
#from spinn2d_copy import Plotter2D, App2D, SPINN2D
from spinn2d_copy_multiscale2 import Plotter2D, App2D, SPINN2D
#from pinn2d import Plotter2D, App2D, SPINN2D

PI = np.pi


class Poisson2D(RegularPDE):
    def pde(self, x, y, u, ux, uy, uxx, uyy):
        #f = 20*PI**2*torch.sin(2*PI*x)*torch.sin(4*PI*y)
        f = 100*PI**2*torch.sin(6*PI*x)*torch.sin(8*PI*y)
        return 0.1*(uxx + uyy + f)

    def has_exact(self):
        return True

    def exact(self, x, y):
        #return np.sin(2*PI*x)*np.sin(4*PI*y)
        return np.sin(6*PI*x)*np.sin(8*PI*y)

    def boundary_loss(self, nn):
        xb, yb = self.boundary()
        xbn, ybn = (t.detach().cpu().numpy() for t in (xb, yb))

        u = nn(xb, yb)
        ub = tensor(self.exact(xbn, ybn))
        bc = u - ub
        return (bc**2).sum()


if __name__ == '__main__':
    app = App2D(
        pde_cls=Poisson2D, nn_cls=SPINN2D,
        plotter_cls=Plotter2D
    )
    app.run(nodes=100, samples=400, n_train=20000, lr=1e-3, tol=5e-5,#optimizer='Rprop',#optimizer='LBFGS',#1e-3, 
    directory='paperuse',
    plot=True,activation='gaussian', pu=True, gpu=True)#kernel gaussian
    #print("model have {} paramerters in total".format(sum(x.numel() for x in app.nn.parameters() if x.requires_grad)))
    #app.shape_parameter_error()
1
