

import numpy as np
import torch

from common import tensor
from ode_base import BasicODE
#from spinn1d import Plotter1D, SPINN1D, App1D
#from spinn1d_copy import App1D, SPINN1D, Plotter1D #multiscale_no_head
#from spinn1d_copy_multiscale import App1D, SPINN1D, Plotter1D 
from spinn1d_copy_multiscale2 import App1D, SPINN1D, Plotter1D 



class ODESimple(BasicODE):
    def pde(self, x, u, ux, uxx):
        #return uxx + 1.0
        return uxx+np.pi*np.pi*torch.sin(np.pi*x)

    def has_exact(self):
        return True

    def exact(self, x):
        #return 0.5*x*(1.0 - x)
        return np.sin(np.pi*x)

    def boundary_loss(self, nn):
        u = nn(self.boundary())
        ub = tensor(self.exact(self.xbn))
        bc = u - ub
        return (bc**2).sum()
        # return torch.abs(bc).max()

    def plot_points(self):
        n = 25
        x = np.linspace(0.0, 1.0, n)
        return x

if __name__ == '__main__':
    app = App1D(
        pde_cls=ODESimple, nn_cls=SPINN1D,
        plotter_cls=Plotter1D
    )
    app.run(nodes=3, samples=19, lr=1e-4, n_train=20000, tol=2.5e-7,#nodes=3/5/7,samples=19/31/43,n_train=10000,tol=2.5e-5
    plot=True, activation='gaussian',pu=True,directory='paperuse'
    )

1
