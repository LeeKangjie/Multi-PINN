import os
import torch
import sys
import torch.nn as nn
import numpy as np
from mayavi import mlab
import matplotlib.pyplot as plt

from common import Plotter, App, tensor


class Plotter2D(Plotter):
    def get_error(self, xn=None, yn=None, pn=None):
        if not self.pde.has_exact():
            return 0.0, 0.0, 0.0

        if xn is None and pn is None:
            xn, yn, pn = self.get_plot_data()

        un = self.pde.exact(xn, yn)
        diff = un - pn
        err_L1 = np.mean(np.abs(diff))
        err_L2 = np.sqrt(np.mean(diff**2))
        err_Linf = np.max(np.abs(diff))
        return err_L1, err_L2, err_Linf

    def save(self, dirname):
        '''Save the model and results.

        '''
        modelfname = os.path.join(dirname, 'model.pt')
        torch.save(self.nn.state_dict(), modelfname)
        rfile = os.path.join(dirname, 'results.npz')
        x, y, u= self.get_plot_data()
        u_exact = self.pde.exact(x,y)
        np.savez(rfile, x=x, y=y, u=u, u_exact=u_exact)

    # Plotting methods
    def get_plot_data(self):
        x,y = self.pde.plot_points()
        xt,yt = tensor(x.ravel()), tensor(y.ravel())
        pn = self.nn(xt, yt).detach().cpu().numpy()
        pn.shape = x.shape
        return x, y, pn

    def plot_solution(self):
        xn, yn, pn = self.get_plot_data()
        pde = self.pde
        if self.plt1 is None:
            mlab.figure(
                size=(700, 700), fgcolor=(0, 0, 0), bgcolor=(1, 1, 1)
            )
            #cmap = 'viridis'
            cmap = 'jet'
            #if self.show_exact and pde.has_exact():
            #    un = pde.exact(xn, yn)
            #    mlab.surf(xn, yn, un,
            #              colormap=cmap, representation='wireframe')
            #self.plt1 = mlab.surf(xn, yn, pn, colormap=cmap, opacity=0.8)
            self.plt1 = mlab.surf(xn, yn, pn, colormap=cmap)
            mlab.colorbar(self.plt1)
        else:
            self.plt1.mlab_source.scalars = pn
        return self.get_error(xn, yn, pn)

    def plot(self):
        err = self.plot_solution()
        #self.plot_weights()
        mlab.process_ui_events()
        if sys.platform.startswith('linux'):
            self.plt1.scene._lift()
        return err

    def show(self):
        plt.show()


class SPINN2D(nn.Module):
    @classmethod
    def from_args(cls, pde, activation, args):
        #return cls(pde, activation, args.neurons, args.layers, args.method)
        return cls(pde, activation)

    @classmethod
    def setup_argparse(cls, parser, **kw):
        p = parser
        p.add_argument(
            '--neurons', dest='neurons', type=int,
            default=kw.get('neurons', 10),
            help='Number of neurons per layer.'
        )
        p.add_argument(
            '--layers', dest='layers', default=kw.get('layers', 5),
            type=int, help='Number of hidden layers.'
        )
        p.add_argument(
            '--method', dest='method', default=kw.get('method', 'generic'),
            action='store', choices=['kernel', 'simple', 'generic'],
            help='The method to use to setup the neurons and layers.'
        )

    def __init__(self, pde, activation, neurons=128, layers=4):


        super().__init__()
        # PDE and activation are ignored and not used here.
        self.n = n = neurons
        self.nl = nl = layers
        
        layers = [nn.Linear(2, n), nn.Tanh()]
        for i in range(nl - 2):
            layers.extend([nn.Linear(n, n), nn.Tanh()])
        layers.append(nn.Linear(n, 1))

        self.model = nn.Sequential(*layers)

    def forward(self, x, y):
        x = x.unsqueeze(1)
        y = y.unsqueeze(1)
        input=torch.hstack((x,y))
        return self.model(input).squeeze()

    def centers(self):
        return tensor([]), tensor([])

    def widths(self):
        return tensor([])


class App2D(App):
    def _setup_activation_options(self, p, **kw):
        pass

    def _get_activation(self, args):
        pass
