# Solve Poisson equation in 2D using SPINN
# \nabla^2 u(x, y) = 20pi^2 sin(2pi x) sin(4pi y) on [0,1]x[0,1]
# Zero Dirichlet boundary condition on boundary

import numpy as np
import torch
from pde2d_base import RegularPDE
from common import tensor
#from spinn2d import Plotter2D, SPINN2D, App2D
#from spinn2d_copy import Plotter2D, App2D, SPINN2D
from spinn2d_copy_multiscale2 import Plotter2D, App2D, SPINN2D
#from pinn2d import Plotter2D, App2D, SPINN2D

PI = np.pi


class Poisson2D(RegularPDE):
    def pde(self, x, y, u, ux, uy, uxx, uyy):

        f = 20*PI**2*torch.sin(2*PI*x)*torch.sin(4*PI*y)



        return 0.1*(uxx + uyy + f)
    
    def pde2(self, x, y, u, ux, uy, uxx, uyy):

        f = 1
        return 0.1*(uxx + uyy + f)

    def has_exact(self):
        return False

    '''
    def exact(self, x, y):

        return np.sin(2*PI*x)*np.sin(4*PI*y)
        #return np.sin(2*PI*x+2*PI*x*x)*np.sin(4*PI*y+4*PI*y*y)
    '''

    def boundary_loss(self, nn):
        xb, yb = self.boundary()
        xbn, ybn = (t.detach().cpu().numpy() for t in (xb, yb))

        u = nn(xb, yb)
        #ub = tensor(self.exact(xbn, ybn))
        ub = tensor(0)
        bc = u - ub
        return (bc**2).sum()#+self.interface_loss(nn)
    

    def _get_residue(self, nn):
        xs, ys = self.interior()
        #interior1
        xs1=xs[ys>0.5]
        ys1=ys[ys>0.5]
        #interior2
        xs2=xs[ys<=0.5]
        ys2=ys[ys<=0.5]

        u1 = nn(xs1, ys1)
        u, ux, uy, uxx, uyy = self._compute_derivatives(u1, xs1, ys1)
        res = self.pde(xs1, ys1, u, ux, uy, uxx, uyy)
        
        u2 = nn(xs2, ys2)
        u, ux, uy, uxx, uyy = self._compute_derivatives(u2, xs2, ys2)
        res2 = self.pde2(xs2, ys2, u, ux, uy, uxx, uyy)

        return res,res2

    def interior_loss(self, nn):
        res,res2 = self._get_residue(nn)
        return (res**2).mean()+(res2**2).mean()

    def interface_sample(self):

        sl = slice(0.0, 1.0, self.nbs*1j)
        x, y = np.mgrid[sl, sl]
        cond = ((y == 0.5))
        xb, yb = (tensor(t.ravel(), requires_grad=True)
                  for t in (x[cond], y[cond]))
        self.interface_samples = (xb, yb)
        return xb, yb
    
  
    def interface_loss(self,nn):
        xs, ys=self.interface_sample
        u1 = nn(xs, ys)
        u, ux, uy, uxx, uyy = self._compute_derivatives(u1, xs, ys)

        uy_exact=4*PI*np.sin(2*PI*xs)*np.cos(4*PI*ys)
        return ((uy-uy_exact)**2).sum()


if __name__ == '__main__':
    app = App2D(
        pde_cls=Poisson2D, nn_cls=SPINN2D,
        plotter_cls=Plotter2D
    )
    app.run(nodes=150, samples=600, n_train=15000, lr=1e-3, tol=5e-5, #20000
    directory='paperuse',
    plot=True,activation='gaussian', pu=True, gpu=True)#kernel gaussian
    #print("model have {} paramerters in total".format(sum(x.numel() for x in app.nn.parameters() if x.requires_grad)))
    #app.shape_parameter_error()
1
