import os

import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn

from common import Plotter, App, tensor


class Plotter1D(Plotter):
    def get_error(self, xn=None, pn=None):
        if not self.pde.has_exact():
            return 0.0, 0.0, 0.0

        if xn is None and pn is None:
            xn, pn = self.get_plot_data()

        yn = self.pde.exact(xn)
        diff = yn - pn
        err_L1 = np.mean(np.abs(diff))
        err_L2 = np.sqrt(np.mean(diff**2))
        err_Linf = np.max(np.abs(diff))
        return err_L1, err_L2, err_Linf

    def save(self, dirname):
        '''Save the model and results.

        '''
        modelfname = os.path.join(dirname, 'model.pt')
        torch.save(self.nn.state_dict(), modelfname)
        rfile = os.path.join(dirname, 'results.npz')
        x, y = self.get_plot_data()
        y_exact = self.pde.exact(x)
        np.savez(rfile, x=x, y=y, y_exact=y_exact)

    # Plotting methods
    def get_plot_data(self):
        x = self.pde.plot_points()
        xt = tensor(x)
        pn = self.nn(xt).detach().cpu().numpy()
        return x, pn

    def plot_solution(self):
        xn, pn = self.get_plot_data()
        pde = self.pde
        if self.plt1 is None:
            lines, = plt.plot(xn, pn, '-+', label='computed')#'-' '-+'
            self.plt1 = lines
            if self.show_exact and pde.has_exact():
                yn = self.pde.exact(xn)
                plt.plot(xn, yn, label='exact')
            else:
                yn = pn
            plt.grid()
            plt.xlim(-0.1, 1.1)
            ymax, ymin = np.max(yn), np.min(yn)
            delta = (ymax - ymin)*0.5
            plt.ylim(ymin - delta, ymax + delta)
        else:
            self.plt1.set_data(xn, pn)
        return self.get_error(xn, pn)

    def plot(self):
        first = self.plt1 is None
        err = self.plot_solution()
        if first:
            plt.legend()
            plt.pause(0.001)
        else:
            fig = plt.gcf()
            fig.canvas.draw()
            fig.canvas.flush_events()
        return err

    def show(self):
        plt.show()

class SPINN1D(nn.Module):
    @classmethod
    def from_args(cls, pde, activation, args):
        #return cls(pde, activation, args.neurons, args.layers, args.method)
        return cls(pde, activation)

    @classmethod
    def setup_argparse(cls, parser, **kw):
        p = parser
        p.add_argument(
            '--neurons', dest='neurons', type=int,
            default=kw.get('neurons', 10),
            help='Number of neurons per layer.'
        )
        p.add_argument(
            '--layers', dest='layers', default=kw.get('layers', 5),
            type=int, help='Number of hidden layers.'
        )
        p.add_argument(
            '--method', dest='method', default=kw.get('method', 'generic'),
            action='store', choices=['kernel', 'simple', 'generic'],
            help='The method to use to setup the neurons and layers.'
        )

    def __init__(self, pde, activation, neurons=256, layers=4):


        super().__init__()
        # PDE and activation are ignored and not used here.
        self.n = n = neurons
        self.nl = nl = layers
        
        layers = [nn.Linear(1, n), nn.Tanh()]
        for i in range(nl - 2):
            layers.extend([nn.Linear(n, n), nn.Tanh()])
        layers.append(nn.Linear(n, 1))

        self.model = nn.Sequential(*layers)

    def forward(self, x):
        x = x.unsqueeze(1)
        return self.model(x).squeeze()

    def centers(self):
        return tensor([]), tensor([])

    def widths(self):
        return tensor([])


class App1D(App):
    def _setup_activation_options(self, p, **kw):
        pass

    def _get_activation(self, args):
        pass
