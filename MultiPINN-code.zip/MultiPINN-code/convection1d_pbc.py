

import os
import numpy as np
import torch

from common import tensor
from ibvp2d_base import IBVP2D
#from spinn2d import Plotter2D, SPINN2D, App2D
#from spinn2d_copy import Plotter2D, App2D, SPINN2D
#from spinn2d_copy_multiscale import Plotter2D, App2D, SPINN2D
#from spinn2d_copy_multiscale2 import Plotter2D, App2D, SPINN2D
from pinn2d import Plotter2D, App2D, SPINN2D


class Advection1D(IBVP2D):
    @classmethod
    def from_args(cls, args):
        return cls(args.nodes, args.samples,
                   args.b_nodes, args.b_samples,
                   args.xL, args.xR, args.T,
                   args.ic, args.sample_frac)

    @classmethod
    def setup_argparse(cls, parser, **kw):
        super().setup_argparse(parser, **kw)
        p = parser
        p.add_argument(
            '--ic', dest='ic', default=kw.get('ic', 'sin2'),
            choices=['hat', 'gaussian', 'sin', 'sin2'],
            help='Initial profiles for linear advection equation.'
        )

    def __init__(self, n, ns, nb=None, nbs=None,
                 xL=0.0, xR=1.0, T=1.0, ic='gaussian', sample_frac=1.0):
        super().__init__(n, ns, nb, nbs, xL, xR, T, sample_frac)
        self.ic = ic

    def pde(self, x, t, u, ux, ut, uxx, utt):
        beta =4
        return ut + beta*ux

    def has_exact(self):

        #return False
        return True

    def exact(self, x_in, t_in):
        if self.ic == 'sin2':
            
            nu=0
            beta=4*np.pi*2 

            x=x_in[:,0]
            nt=t_in.shape[0]
            t=np.linspace(0, 1, nt).reshape(-1, 1)
            N=x.shape[0]
            X, T = np.meshgrid(x, t)

            u0 = lambda x: np.sin(2*np.pi*x)
            u0 = u0(x)

            G = (np.copy(u0)*0)

            IKX_pos =1j * np.arange(0, N/2+1, 1)
            IKX_neg = 1j * np.arange(-N/2+1, 0, 1)
            IKX = np.concatenate((IKX_pos, IKX_neg))
            IKX2 = IKX * IKX

            uhat0 = np.fft.fft(u0)
            nu_factor = np.exp(nu * IKX2 * T- beta * IKX * T)
            A = uhat0 - np.fft.fft(G)*0 
            uhat = A*nu_factor + np.fft.fft(G)*T
            u = np.real(np.fft.ifft(uhat))

            return u.transpose()

    def boundary_condition(self, x):
        z = x
        y = np.heaviside(z, 0.5) - np.heaviside(z - 1.0, 0.5)
        return y*np.sin(z*np.pi*2)



    def boundary_loss(self, nn):
        xb, tb = self.boundary()
        u = nn(xb, tb)
        ub = self.boundary_condition(xb[:self.nsx].detach().cpu().numpy())#, tb[:self.nsx].detach().cpu().numpy())
        bc = u[:self.nsx] - tensor(ub)
        l=(bc**2).sum()
        

        u_low_bd_pred=u[self.nsx:self.nsx+self.nst]
        u_ip_bd_pred=u[self.nsx+self.nst:]
        loss_pbd=torch.sum((u_ip_bd_pred - u_low_bd_pred) ** 2)
        l=l+loss_pbd
        
        return l


class MyPlotter(Plotter2D):
    def save(self, dirname):
        '''Save the model and results.

        '''
        nn = self.nn
        modelfname = os.path.join(dirname, 'model.pt')
        torch.save(nn.state_dict(), modelfname)
        rfile = os.path.join(dirname, 'results.npz')
        xp, yp, up = self.get_plot_data()
        uex_p = self.pde.exact(xp, yp)
        x, t = np.mgrid[-1:1:200j, 0:1:11j]
        xt, tt = tensor(x.ravel()), tensor(t.ravel())
        u = nn(xt, tt).detach().cpu().numpy()
        u.shape = x.shape
        u_exact = self.pde.exact(x, t)
        np.savez(rfile, x=x, t=t, u=u, u_exact=u_exact,
                 xp=xp, yp=yp, up=up, uex_p=uex_p)


if __name__ == '__main__':
    app = App2D(
        pde_cls=Advection1D,
        nn_cls=SPINN2D,
        plotter_cls=MyPlotter
    )
    app.run(nodes=200, samples=1600, xL=0, xR=1.0, lr=1e-3,n_train=10000,#n_train=10000 lr=1e-2
    directory='paperuse',plot=True,activation='gaussian', pu=True, gpu=True)#gaussian kernel 
    
    #print("model have {} paramerters in total".format(sum(x.numel() for x in app.nn.parameters() if x.requires_grad)))
    #app.loss_landscape()
    #app.shape_parameter_error()
1
